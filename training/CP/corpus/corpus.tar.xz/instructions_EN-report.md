# Sampling report

## Parameters
- dataset: HiTZ/Magpie-Llama-3.1-70B-Instruct-Filtered-1M (train split)
- mode: rows
- requested: 10000 rows
- seed: 42
- tokenizer: HiTZ/Latxa-Llama-3.1-70B-Instruct-v2
- text field: conversations
- max tokens per entry: 8192 (longer entries skipped)
- output: instructions_EN.jsonl

## Outcome
- corpus rows (train): 1000000
- sampled rows: 10000 (1.0000% of corpus)
- sampled tokens: 4975846
- skipped entries longer than 8192 tokens: 0 (0.00% of examined)
- tokens per entry: min 51, mean 497.6, median 500, max 4132

## Per source
| source | corpus rows | sampled rows | sampled tokens | skipped (> 8192 tokens) |
|---|---|---|---|---|
| default | 1000000 | 10000 | 4975846 | 0 (0.00%) |
