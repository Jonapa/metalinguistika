# Sampling report

## Parameters
- dataset: HiTZ/latxa-corpus-v2 (train split)
- mode: tokens
- requested: 60000000 tokens
- seed: 42
- tokenizer: HiTZ/Latxa-Llama-3.1-70B-Instruct-v2
- text field: text
- max tokens per entry: 8192 (longer entries skipped)
- output: latxa_corpus.jsonl

## Outcome
- corpus rows (train): 5653987
- sampled rows: 68329 (1.2085% of corpus)
- sampled tokens: 60007188
- skipped entries longer than 8192 tokens: 1424 (2.04% of examined)
- tokens per entry: min 5, mean 878.2, median 526, max 8192

## Per source
| source | corpus rows | sampled rows | sampled tokens | skipped (> 8192 tokens) |
|---|---|---|---|---|
| wikipedia | 456273 | 5641 | 1974509 | 13 (0.23%) |
| euscrawl-v2 | 1636010 | 20563 | 12302207 | 11 (0.05%) |
| zelaihandi | 189975 | 2181 | 2008403 | 68 (3.02%) |
| bog | 169665 | 1930 | 1675932 | 87 (4.31%) |
| bopv | 42798 | 442 | 742140 | 76 (14.67%) |
| botha | 92249 | 1100 | 1011591 | 41 (3.59%) |
| parleus | 22818 | 308 | 501848 | 2 (0.65%) |
| aldizkariak | 2918 | 15 | 63152 | 28 (65.12%) |
| cultura-x | 870464 | 10418 | 11259631 | 132 (1.25%) |
| hplt-v2 | 567503 | 6951 | 5687372 | 78 (1.11%) |
| finepdfs | 277572 | 2727 | 5257180 | 673 (19.79%) |
| fineweb2 | 341296 | 4215 | 3368409 | 36 (0.85%) |
| colossal-oscar | 89856 | 1085 | 842079 | 16 (1.45%) |
| hplt-v1 | 894590 | 10753 | 13312735 | 163 (1.49%) |
