# Corpus report

- Tokenizer: `HiTZ/Latxa-Llama-3.1-70B-Instruct-v2`
- Files: 39
- Entries: 17174
- Tokens: 6,543,489

## Datasets

| dataset | files | entries | tokens | share |
|---|---:|---:|---:|---:|
| 1-berria_qa | 1 | 117 | 36,436 | 0.6% |
| 2-berria_hiztegia | 1 | 9910 | 397,254 | 6.1% |
| 3-berria_idazkuntza | 1 | 16 | 44,756 | 0.7% |
| 4-dudanet | 1 | 689 | 135,954 | 2.1% |
| 5-EBE | 1 | 1163 | 392,022 | 6.0% |
| 6-EHUTSI | 1 | 102 | 73,843 | 1.1% |
| 7-JAGONET | 1 | 878 | 267,355 | 4.1% |
| 8-SEG | 1 | 103 | 41,541 | 0.6% |
| 9-UZEI | 1 | 63 | 38,372 | 0.6% |
| 10-zalantza_dantza | 1 | 391 | 76,390 | 1.2% |
| 11-EGLU | 8 | 378 | 1,931,509 | 29.5% |
| 12-euskararen_gramatika | 1 | 1124 | 1,614,452 | 24.7% |
| 13-galdezka | 1 | 43 | 163,818 | 2.5% |
| 14-irale | 7 | 422 | 321,683 | 4.9% |
| 15-morfonsintaxia | 1 | 175 | 126,914 | 1.9% |
| 16-gramatika_osoa | 1 | 83 | 57,837 | 0.9% |
| 17-elhuyar | 1 | 60 | 50,599 | 0.8% |
| 18-eibz | 1 | 283 | 100,225 | 1.5% |
| 19-araugintza | 1 | 78 | 29,523 | 0.5% |
| 20-ikasbil | 1 | 30 | 51,118 | 0.8% |
| 21-kalko | 1 | 439 | 259,086 | 4.0% |
| 22-ehulku | 1 | 209 | 228,307 | 3.5% |
| 23-azpidazki | 4 | 418 | 104,495 | 1.6% |

## Files

| file | dataset | entries | tokens | min | mean | max |
|---|---|---:|---:|---:|---:|---:|
| 1-berria_qa/berria_qa.md | 1-berria_qa | 117 | 36,436 | 69 | 311 | 1757 |
| 2-berria_hiztegia/berria_hiztegia.md | 2-berria_hiztegia | 9910 | 397,254 | 13 | 40 | 1126 |
| 3-berria_idazkuntza/berria_idazkuntza.md | 3-berria_idazkuntza | 16 | 44,756 | 557 | 2797 | 4434 |
| 4-dudanet/dudanet.md | 4-dudanet | 689 | 135,954 | 13 | 197 | 1810 |
| 5-EBE/EBE.md | 5-EBE | 1163 | 392,022 | 26 | 337 | 3661 |
| 6-EHUTSI/ehutsi.md | 6-EHUTSI | 102 | 73,843 | 350 | 724 | 1886 |
| 7-JAGONET/jagonet.md | 7-JAGONET | 878 | 267,355 | 60 | 305 | 1341 |
| 8-SEG/seg_zalantzak.md | 8-SEG | 103 | 41,541 | 57 | 403 | 2091 |
| 9-UZEI/uzei_gomendioak.md | 9-UZEI | 63 | 38,372 | 260 | 609 | 1229 |
| 10-zalantza_dantza/Zalantza-dantza_2022.md | 10-zalantza_dantza | 391 | 76,390 | 26 | 195 | 1053 |
| 11-EGLU/EGLU_I.md | 11-EGLU | 46 | 231,709 | 1320 | 5037 | 7433 |
| 11-EGLU/EGLU_II.md | 11-EGLU | 48 | 255,478 | 1636 | 5322 | 7555 |
| 11-EGLU/EGLU_III.md | 11-EGLU | 26 | 134,836 | 1790 | 5186 | 7375 |
| 11-EGLU/EGLU_IV.md | 11-EGLU | 32 | 147,462 | 1129 | 4608 | 7427 |
| 11-EGLU/EGLU_V.md | 11-EGLU | 57 | 285,864 | 1702 | 5015 | 7147 |
| 11-EGLU/EGLU_VI.md | 11-EGLU | 52 | 285,924 | 1375 | 5499 | 7450 |
| 11-EGLU/EGLU_VII.md | 11-EGLU | 66 | 336,400 | 1498 | 5097 | 7349 |
| 11-EGLU/Euskal_Gramatika_Laburra.md | 11-EGLU | 51 | 253,836 | 1142 | 4977 | 7357 |
| 12-euskararen_gramatika/euskararen_gramatika_EGLU.md | 12-euskararen_gramatika | 1124 | 1,614,452 | 35 | 1436 | 13488 |
| 13-galdezka/Galdezka.md | 13-galdezka | 43 | 163,818 | 897 | 3810 | 8100 |
| 14-irale/1_zalantzak.md | 14-irale | 142 | 114,910 | 94 | 809 | 3830 |
| 14-irale/2_zalantzak.md | 14-irale | 57 | 56,126 | 207 | 985 | 2673 |
| 14-irale/3_zalantzak.md | 14-irale | 85 | 58,766 | 66 | 691 | 2195 |
| 14-irale/4_zalantzak.md | 14-irale | 49 | 41,835 | 157 | 854 | 4123 |
| 14-irale/5_zalantzak.md | 14-irale | 33 | 19,768 | 128 | 599 | 1470 |
| 14-irale/6_zalantzak.md | 14-irale | 37 | 19,840 | 157 | 536 | 1398 |
| 14-irale/7_zalantzak.md | 14-irale | 19 | 10,438 | 106 | 549 | 1233 |
| 15-morfonsintaxia/MORFOSINTAXIA.md | 15-morfonsintaxia | 175 | 126,914 | 76 | 725 | 4730 |
| 16-gramatika_osoa/merged_clean.md | 16-gramatika_osoa | 83 | 57,837 | 113 | 697 | 2034 |
| 17-elhuyar/elhuyar.md | 17-elhuyar | 60 | 50,599 | 228 | 843 | 2926 |
| 18-eibz/eibz.md | 18-eibz | 283 | 100,225 | 46 | 354 | 1567 |
| 19-araugintza/araugintza.md | 19-araugintza | 78 | 29,523 | 53 | 378 | 1569 |
| 20-ikasbil/ikasbil_hizkuntza_arauak.md | 20-ikasbil | 30 | 51,118 | 228 | 1704 | 5335 |
| 21-kalko/kalkoak.md | 21-kalko | 439 | 259,086 | 45 | 590 | 2868 |
| 22-ehulku/ehulku_aholkuak.md | 22-ehulku | 209 | 228,307 | 150 | 1092 | 3025 |
| 23-azpidazki/argitokia_zalantzak.md | 23-azpidazki | 147 | 26,969 | 32 | 183 | 724 |
| 23-azpidazki/erdarakadak.md | 23-azpidazki | 123 | 5,054 | 23 | 41 | 73 |
| 23-azpidazki/gramatika.md | 23-azpidazki | 90 | 46,739 | 25 | 519 | 7265 |
| 23-azpidazki/jakiteko.md | 23-azpidazki | 58 | 25,733 | 52 | 444 | 2251 |
